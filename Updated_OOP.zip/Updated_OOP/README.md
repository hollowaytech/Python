# =====UPDATED=====OOP=====IN======PYTHON=====

# Updated Object Oriented Program that includes:

# \-Inheritance

# \-Classes

# \-Objects/Instances

# \-Methods

# \-Time Function

