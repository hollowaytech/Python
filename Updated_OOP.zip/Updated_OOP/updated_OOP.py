import time

class password:
    def __init__(self, password:str, passcorrect:bool):
        self.password = password
        self.passcorrect = passcorrect
        
class attempts(password):
    def __init__(self, password:str, passcorrect:bool, attempts:int):
        super().__init__(password, passcorrect)
        self.attempts = attempts

class final(attempts):
    def __init__(self, password:str, passcorrect:bool, attempts:int):
        super().__init__(password, passcorrect, attempts)
    def __repr__(self):
        if self.passcorrect == True:
            return f"Attempt: {self.attempts}\nPassword Entered: {self.password}\nVerdict: PASSWORD CORRECT, ACCESS GRANTED."
        else:
            return f"Attempt: {self.attempts}\nPassword Entered: {self.password}\nVerdict: PASSWORD INCORRECT, ACCESS DENIED."

att1 = final("abc125", False, 1)
att2 = final("abC123", False, 2)
att3 = final("abb124", False, 3)
att4 = final("abc121", False, 4)
att5 = final("abc123", True, 5)

log_choice = input("Press 'Y' to pull up password logs: ")
if log_choice == "Y":
    print(" ")
    print("Loading logs...")
    time.sleep(2.5)
    print(" ")
    print("Still loading...")
    time.sleep(2.5)
    print(" ")
    print("PASSWORD LOGS:")
    time.sleep(0.75)
    print("====================")
    print(att1)
    time.sleep(0.75)
    print("====================")
    print(att2)
    time.sleep(0.75)
    print("====================")
    print(att3)
    time.sleep(0.75)
    print("====================")
    print(att4)
    time.sleep(0.75)
    print("====================")
    print(att5)
    print("====================")
else:
    print("\n.....")