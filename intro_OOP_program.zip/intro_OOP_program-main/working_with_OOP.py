class food:
  all = []
  def __init__(self, type):
    self.type = type
    food.all.append(self)
    assert self.type > " ", "Food type CANNOT be an empty space."
  def __repr__(self):
    return f"{self.type}"
fruit = food("fruit")
vege = food("vegetables")
meat = food("meat")
nuts = food("nuts")
print("Types of foods: ")
print(food.all)
print(" ")
print("Code dictionary: ")
print(food.__dict__)
print(" ")
class fruit:
  all = []
  def __init__(self, type):
    self.type = type
    fruit.all.append(self)
    assert self.type > " ", "Fruit type CANNOT be an empty space."
  def __repr__(self):
    return f"{self.type}"
ap = fruit("apple")
ora = fruit("orange")
ban = fruit("bananna")
gra = fruit("grape")
print("Types of fruits: ")
print(fruit.all)
print(" ")
print("Code dictionary: ")
print(fruit.__dict__)
print(" ")
class vege:
  all = []
  def __init__(self, type):
    self.type = type
    vege.all.append(self)
    assert self.type > " ", "Vegetable type CANNOT be an empty space."
  def __repr__(self):
    return f"{self.type}"
bro = vege("broccoli")
corn = vege("corn")
car = vege("carrot")
oni = vege("onion")
print("Types of vegetables: ")
print(vege.all)
print(" ")
print("Code dictionary: ")
print(vege.__dict__)
print(" ")
class meat:
  all = []
  def __init__(self, type):
    self.type = type
    meat.all.append(self)
    assert self.type > " ", "Meat type CANNOT be an empty space."
  def __repr__(self):
    return f"{self.type}"
beef = meat("beef")
chi = meat("chicken")
fih = meat("fish")
pork = meat("pork")
print("Types of meat: ")
print(meat.all)
print(" ")
print("Code dictionary: ")
print(meat.__dict__)
print(" ")
class nuts:
  all = []
  def __init__(self, type):
    self.type = type
    nuts.all.append(self)
    assert self.type > " ", "Nut type CANNOT be an empty space."
  def __repr__(self):
    return f"{self.type}"
pec = nuts("pecans")
pean = nuts("peanuts")
alm = nuts("almonds")
cash = nuts("cashews")
print("Types of nuts: ")
print(nuts.all)
print(" ")
print("Code dictionary: ")
print(nuts.__dict__)
print(" ")
class drink:
  all = []
  def __init__(self, type):
    self.type = type
    drink.all.append(self)
    assert self.type > " ", "Drink type CANNOT be an empty space."
  def __repr__(self):
    return f"{self.type}"
wat = drink("water")
sod = drink("soda")
tea = drink("tea")
beer = drink("beer")
print("Types of drinks: ")
print(drink.all)
print(" ")
print("Code dictionary: ")
print(drink.__dict__)
print(" ")