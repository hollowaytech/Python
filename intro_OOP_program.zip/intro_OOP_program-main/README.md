=======================================**=====================INTRO TO PYTHON OOP PROJECT====================**=======================================

* This program organizes different data sets (food and drinks) in specific classes to emphasize the importance and convenience of Object Oriented Programming (OOP)

